CREATE TABLE member1(
	id NUMBER PRIMARY KEY,
	name VARCHAR2(20),
	email  VARCHAR2(30),
	phone VARCHAR2(20)
);

CREATE SEQUENCE member1_seq;